# Session handoff — updated 2026-10-23 (Explorer catalog live-capture patch; Auth-Key primary)

Continue from here in the next chat. User will also add admin/customer portal + website repos later.

## Auth — OK (Session-Id refreshed 2026-10-23; Auth-Key primary)

Permanent **Auth-Key** in `secrets.local.json` (gitignored) remains primary for long capture runs. Session-Id was refreshed on **2026-10-23** (redacted `in3f3af1********HbI=`); use for short UI-aligned calls when needed.

Auth-Key redacted: `dNYPuoiWrFz********go=`

Verified: `GET /company/{c}` → 200 success (both headers).

## Masters restored — OK

| Master | Status |
| --- | --- |
| Stock group `apidoc-products` | Restored from `apidoc-temp-sg-342` (PUT rename undo) |
| Customer `apidoc-customer-one` | Back under `sundrydebtors` (parentGroups includes it) |

## FE-pending backlog — COMPLETE (attempted)

| Metric | Value |
| --- | --- |
| This resume (tags **1226–1421**) attempted | **196** FE-used pending |
| This resume success (HTTP 2xx + status success) | **63** |
| This resume fail / soft-fail | **133** |
| Prior batch 1100–1225 | 125 attempted / 24 success (then session killed) |
| FE-used unique attempted | **~636 / 636 (~100%)** |
| Remaining FE-used pending | **0** (`_fe_pending_remaining.json` emptied) |
| Soft success across FE batches | **~87** (many remaining need real bodies/integrations) |

Runner: `_fe_pending_runner.py` (Auth-Key headers + session-killer blacklist).  
Logs: `CALL-LOG-FE-PENDING.json` · `CALL-LOG-2026-10-23.json` · `_fe_pending_run_authkey.log`

### Collateral deletes this run (recreate if needed)

- Role `aft1792738829523` — `1346`
- Tax authority `apidoctaxauthoritymp` — `1350`
- Custom field `1792758792191n1ficygh8s7bfds` — `1295`
- Customer-vendor-discount assignment — `1294`

### Notable successes (1226+)

- Groups: masters, shared-with, download closing-balance, PUT group
- Stock: unit PUT, inventory-report, v2 aging totals/details/variants, stock details, variant PATCH
- Imports: reconciliation GET, signed-url
- VAT reports: UK / Kenya / ZW GET paths; company PATCH; address/all
- Advance-receipt get-all/summary; GoCardless refresh; inventory balance
- Settings/plan/purchase-bill-setting; warehouse PATCH/PUT/default
- Country + cities; white-label; GSTR1 download; save GSTR3B
- Sales/purchase register detailed; multibranch BS/PL downloads; inventory hierarchy download

## Absolute rules

1. Every API call → save **request + response (success AND fail)** under this folder.
2. Accounting MS → always `voucherVersion=2` (except documented exceptions e.g. DC/RN `/all`).
3. curl + browser User-Agent (not Python urllib).
4. Secrets only in `secrets.local.json` (gitignored). Prefer **Auth-Key**.
5. Wire real success JSON into Explorer catalog when working an endpoint.
6. **Never call** destroy-session, logout, revoke-token, wipe-sessions, generate-auth-key, DELETE/GET users/*/sessions, increment-session during capture batches.

## Company

| Field | Value |
| --- | --- |
| Name | Giddh Automation API DOC |
| uniqueName | `giddhain1792673422178091xos` |
| branch | `giddhautomationapidoc` (+ `apidocbranchtwo`) |
| warehouse | `xbq1792673424418` (+ `4gr1792733898078`) |
| GSTIN | `23AAACC1206D2ZN` (default address) |
| FY | 01-04-2026 → 31-03-2027 |
| baseUrl | `https://apitest.giddh.com` |
| UI | `https://test.giddh.com` |
| Auth | **Auth-Key** primary (redacted `dNYPuoiWrFz********go=`); Session-Id refreshed 2026-10-23 (`in3f3af1********HbI=`) |
| billingAccount | `k2b1712141952375` |
| salesperson | `apidocsalesperson` |

## Explorer catalog — refreshed from live captures (2026-10-23)

Both catalogs patched from `responses/*.json` + `CALL-LOG*.json`:

- `tools/giddh-api-explorer/public/data/catalog.json`
- `docs/api/coverage/catalog.json`

| Metric | Count |
| --- | ---: |
| Records patched (any) | **693** |
| Success examples set | **379** |
| Error examples merged | **402** |
| Captures matched / unmatched | 1275 / 81 |

Report: `EXPLORER-CATALOG-PATCH-REPORT.md` · Script: `_patch_explorer_catalog_from_captures.py`  
Local Explorer: hard-refresh after `npm start` in `tools/giddh-api-explorer` (or `npm run sync` then hard-refresh — sync now preserves `liveCapture` / error `when`).

## Next work (priority)

1. Recreate deleted role / tax authority / custom field if later tests need them.
2. Re-probe soft-fails with richer bodies (batch/EWB/HMRC/PayPal/Razorpay/OCR/import multipart).
3. Company invite/share path still unknown (404/405).
4. Invoice template **create** (`copyFrom` still 500 on apitest).
5. Postman chaining; admin/portal repos when available. Optional: rematch 81 unmatched captures / 71 orphan response files.

## Do not

- Deploy Embarko unless asked
- Commit secrets / print full Auth-Key
- Call accounting voucher APIs without `voucherVersion=2`
- Call DC/RN generate without `inventoryViaBusinessDocument=true`
- Send flat manufacturing create body (must nest `manufacturingDetails`)
- Pass `voucherVersion=2` on DC/RN **`/all`** list (causes 404)
- Call **session-killers** during capture batches
- PUT stock-group / account with a **new uniqueName** unless intentionally renaming
