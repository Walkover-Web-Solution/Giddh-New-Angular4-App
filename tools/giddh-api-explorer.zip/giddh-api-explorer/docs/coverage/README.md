# Frontend / Backend API Coverage

| Classification | Count |
|---|---:|
| Frontend calls inventoried | 833 |
| Exact frontend/backend matches | 672 |
| Frontend unmatched | 161 |
| Backend expanded routes | 1392 |
| Backend routes not used by frontend | 737 |
| Explicitly deprecated expanded routes | 6 |

- [Backend not used](./backend-not-used.md)
- [Frontend unmatched](./frontend-unmatched.md)
- [Deprecated](./deprecated.md)
- Machine-readable evidence: `comparison.json`
