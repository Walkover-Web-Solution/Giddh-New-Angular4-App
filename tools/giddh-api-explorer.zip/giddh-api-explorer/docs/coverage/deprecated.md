# Explicitly Deprecated Backend APIs

Only Java `@Deprecated` or Javadoc `@deprecated` controller methods appear here. Backend-not-used routes are not automatically deprecated.

Total expanded deprecated routes: **6**

- `POST /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/ledgers/mail` — giddh-api-v2 · `LedgerController#mailLedgerDetailed` · `src/main/java/com/giddh/api/controllers/v1/LedgerController.java:334` · **deprecated** · frontend used: **no**
- `POST /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/ledgers/mail-condensed` — giddh-api-v2 · `LedgerController#mailLedgerCondensed` · `src/main/java/com/giddh/api/controllers/v1/LedgerController.java:360` · **deprecated** · frontend used: **no**
- `PUT /company/{companyUniqueName}/razorpay/{razorPayUserName}` — giddh-api-v2 · `RazorPayController#mapRazorPayAccount` · `src/main/java/com/giddh/api/controllers/v1/RazorPayController.java:60` · **deprecated** · frontend used: **no**
- `DELETE /company/{companyUniqueName}/razorpay/{razorPayUserName}` — giddh-api-v2 · `RazorPayController#deleteRazorPayAccount` · `src/main/java/com/giddh/api/controllers/v1/RazorPayController.java:87` · **deprecated** · frontend used: **no**
- `GET /magic-link/{magicLink}` — giddh-api-v2 · `MagicLinkController#getLedgers` · `src/main/java/com/giddh/api/controllers/v1/MagicLinkController.java:51` · **deprecated** · frontend used: **yes**
- `GET /company/{companyUniqueName}/particular-search` — search-api · `SearchController#particularSearch` · `src/main/java/com/giddh/api/controllers/SearchController.java:175` · **deprecated** · frontend used: **no**
