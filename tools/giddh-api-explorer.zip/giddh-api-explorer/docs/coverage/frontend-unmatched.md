# Frontend APIs Without a Backend Controller Match

These calls did not match any of the four checked backend snapshots by exact normalized method/path.

Total: **161**

## `GET /subscriptions/all?countryCode=:countryCode`

- Frontend id: `LOGIN_API.GET_USER_SUBSCRIPTION_PLAN_API`
- Evidence: `apps/web-giddh/src/app/services/authentication.service.ts#getAllUserSubsciptionPlans`
- Candidates: none

## `POST /users/system_admin/verify-number`

- Frontend id: `LOGIN_API.VerifyNumber`
- Evidence: `apps/web-giddh/src/app/services/authentication.service.ts#VerifyNumber; apps/web-giddh/src/app/services/authentication.service.ts#VerifyNumberOTP`
- Candidates: `POST /users/{userUniqueName}/verify-number` (giddh-api-v2), `PUT /users/{userUniqueName}/verify-number` (giddh-api-v2)

## `PUT /users/system_admin/verify-number`

- Frontend id: `LOGIN_API.VerifyNumber`
- Evidence: `apps/web-giddh/src/app/services/authentication.service.ts#VerifyNumber; apps/web-giddh/src/app/services/authentication.service.ts#VerifyNumberOTP`
- Candidates: `POST /users/{userUniqueName}/verify-number` (giddh-api-v2), `PUT /users/{userUniqueName}/verify-number` (giddh-api-v2)

## `PUT /company/:companyUniqueName/branch`

- Frontend id: `COMPANY_API.CREATE_NEW_BRANCH`
- Evidence: `apps/web-giddh/src/app/services/company.service.ts#createNewBranch; apps/web-giddh/src/app/services/company.service.ts#updateBranch`
- Candidates: `POST /company/{companyUniqueName}/branch` (giddh-api-v2), `GET /company/{companyUniqueName}/branch` (giddh-api-v2), `POST /company/{companyUniqueName}/branch` (giddh-api-v2), `GET /company/{companyUniqueName}/branch` (giddh-api-v2), `GET /company/{companyUniqueName}/branch/{branchUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/tax`

- Frontend id: `COMPANY_API.TAX`
- Evidence: `apps/web-giddh/src/app/services/company.service.ts#getCompanyTaxes; apps/web-giddh/src/app/services/settings.taxes.service.ts#CreateTax; apps/web-giddh/src/app/services/settings.taxes.service.ts#UpdateTax; apps/web-giddh/src/app/services/settings.taxes.service.ts#DeleteTax`
- Candidates: `POST /company/{companyUniqueName}/tax` (giddh-api-v2), `GET /company/{companyUniqueName}/tax` (giddh-api-v2), `POST /company/{companyUniqueName}/tax` (giddh-api-v2), `PUT /company/{companyUniqueName}/tax/{taxUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/tax` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/tax`

- Frontend id: `COMPANY_API.TAX`
- Evidence: `apps/web-giddh/src/app/services/company.service.ts#getCompanyTaxes; apps/web-giddh/src/app/services/settings.taxes.service.ts#CreateTax; apps/web-giddh/src/app/services/settings.taxes.service.ts#UpdateTax; apps/web-giddh/src/app/services/settings.taxes.service.ts#DeleteTax`
- Candidates: `POST /company/{companyUniqueName}/tax` (giddh-api-v2), `GET /company/{companyUniqueName}/tax` (giddh-api-v2), `POST /company/{companyUniqueName}/tax` (giddh-api-v2), `PUT /company/{companyUniqueName}/tax/{taxUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/tax` (giddh-api-v2)

## `POST /company/:companyUniqueName/export`

- Frontend id: `COMPANY_IMPORT_EXPORT_API.EXPORT`
- Evidence: `company-import-export.api.ts`
- Candidates: none

## `POST /company/:companyUniqueName/export-ledgers-v2?from=:from&to=:to`

- Frontend id: `COMPANY_IMPORT_EXPORT_API.EXPORT_LEDGERS`
- Evidence: `company-import-export.api.ts`
- Candidates: none

## `POST /company/:companyUniqueName/import`

- Frontend id: `COMPANY_IMPORT_EXPORT_API.IMPORT`
- Evidence: `company-import-export.api.ts`
- Candidates: none

## `POST /company/:companyUniqueName/import-ledgers`

- Frontend id: `COMPANY_IMPORT_EXPORT_API.IMPORT_LEDGERS`
- Evidence: `company-import-export.api.ts · company-import-export-service.ts#ImportLedgersRequest`
- Candidates: none

## `POST /company/:companyUniqueName/set-branches`

- Frontend id: `SETTINGS_BRANCH_API.CREATE_BRANCHES`
- Evidence: `apps/web-giddh/src/app/services/settings.branch.service.ts#CreateBranches`
- Candidates: none

## `GET /company/:companyUniqueName/children?from=:from&to=:to`

- Frontend id: `SETTINGS_BRANCH_API.GET_ALL_BRANCHES`
- Evidence: `settings.branch.api.ts`
- Candidates: none

## `GET /company/:companyUniqueName/parent`

- Frontend id: `SETTINGS_BRANCH_API.GET_PARENT`
- Evidence: `settings.branch.api.ts`
- Candidates: none

## `DELETE /company/:companyUniqueName/child/:childUniqueName`

- Frontend id: `SETTINGS_BRANCH_API.REMOVE_BRANCH`
- Evidence: `apps/web-giddh/src/app/services/settings.branch.service.ts#RemoveBranch`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/email-content-suggestion` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/condition-suggestion` (giddh-api-v2)

## `POST /company/:companyUniqueName`

- Frontend id: `SETTINGS_COMPANY_AUTH_KEY_API.COMMON`
- Evidence: `settings.company-auth-key.ts · settings.discount.service.ts#CreateDiscount`
- Candidates: `GET /company/{companyUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName:.+}` (giddh-api-v2), `PATCH /company/{companyUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/role/:roleUniqueName/assign`

- Frontend id: `ACCOUNTS_API.SHARE`
- Evidence: `apps/web-giddh/src/app/services/account.service.ts#AccountShare; apps/web-giddh/src/app/services/account.service.ts#Share`
- Candidates: `POST /company/{companyUniqueName}/role/{roleUniqueName}/assign` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `GET /company/:companyUniqueName/flatten-groups-with-accounts?q=:q&page=:page&count=:count&showEmptyGroups=:showEmptyGroups`

- Frontend id: `GROUP_API.FLATTEN_GROUP_WITH_ACCOUNTS`
- Evidence: `apps/web-giddh/src/app/services/group.service.ts#GetFlattenGroupsAccounts`
- Candidates: none

## `GET /company/:companyUniqueName/groups/flatten-groups-accounts?q=:q&page=:page&count=:count&showEmptyGroups=:showEmptyGroups`

- Frontend id: `GROUP_API.FLATTEN_GROUPS_ACCOUNTS`
- Evidence: `group.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/groups/:groupUniqueName/unshare`

- Frontend id: `GROUP_API.UNSHARE`
- Evidence: `apps/web-giddh/src/app/services/group.service.ts#UnShareGroup`
- Candidates: `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `GET /company/:companyUniqueName/salesperson/:uniqueName/archive`

- Frontend id: `SALES_PERSON_ARCHIVE_API`
- Evidence: `sales.person.api.ts`
- Candidates: `POST /company/{companyUniqueName}/salesperson/{uniqueName}/archive` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `GET /:version/company/:companyUniqueName/particular/:accountUniqueName`

- Frontend id: `SEARCH_API.ACCOUNT_DETAIL`
- Evidence: `apps/web-giddh/src/app/services/search.service.ts#loadDetails`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report/totals` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/platform/verify` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/campaign/list` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/campaign/preview` (giddh-api-v2)

## `GET /company/:companyUniqueName/:version/account-search`

- Frontend id: `SEARCH_API.ACCOUNT_SEARCH`
- Evidence: `apps/web-giddh/src/app/services/search.service.ts#searchAccount`
- Candidates: `PATCH /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `DELETE /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2)

## `POST /company/:companyUniqueName/exports`

- Frontend id: `AGINGREPORT_API.EXPORT`
- Evidence: `apps/web-giddh/src/app/services/agingreporting.service.ts#exportAgingReport`
- Candidates: none

## `POST /company/:companyUniqueName/exports?output=:output`

- Frontend id: `DAYBOOK_SEARCH_API.ENTRIES_EXPORT`
- Evidence: `apps/web-giddh/src/app/services/daybook.service.ts#exportDaybookExpandedPost`
- Candidates: none

## `DELETE /company/:companyUniqueName/yodlee/eledgers?transactionId=:transactionId`

- Frontend id: `LEDGER_API.DELETE_BANK_TRANSACTION`
- Evidence: `apps/web-giddh/src/app/services/ledger.service.ts#DeleteBankTransaction`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/exports`

- Frontend id: `LEDGER_API.EXPORT`
- Evidence: `apps/web-giddh/src/app/services/ledger.service.ts#ExportLedger; apps/web-giddh/src/app/services/ledger.service.ts#exportData`
- Candidates: none

## `GET /company/:companyUniqueName/groups/:groupUniqueName/export-ledger/mail-v2?from=:from&to=:to&type=:type&format=:format`

- Frontend id: `LEDGER_API.GET_GROUP_EXPORT_LEDGER`
- Evidence: `ledger.api.ts`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}/merge` (giddh-api-v2)

## `PUT /company/:companyUniqueName/accounts/:accountUniqueName/eledgers/:transactionId`

- Frontend id: `LEDGER_API.MAP_BANK_TRANSACTIONS`
- Evidence: `apps/web-giddh/src/app/services/ledger.service.ts#MapBankTransactions`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report/{stockUniqueName}/details` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/stock-aging-report/{stockUniqueName}/variants` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/platform/{platformUniqueName}/trigger/form` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/entity/{entity}/trigger/conditions` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/campaign/{slug}/fields` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/ledger/upload`

- Frontend id: `LEDGER_API.UPLOAD_FILE`
- Evidence: `apps/web-giddh/src/app/services/ledger.service.ts#removeAttachment`
- Candidates: `POST /company/{companyUniqueName}/ledger/upload` (giddh-api-v2), `GET /company/{companyUniqueName}/ledger/upload` (giddh-api-v2), `POST /company/{companyUniqueName}/ledger/upload` (accounting-microservice), `POST /company/{companyUniqueName}/ledger/upload` (import-microservice), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2)

## `GET /contra`

- Frontend id: `VOUCHERS.CONTRA`
- Evidence: `accounting.constant.ts`
- Candidates: none

## `GET /journal`

- Frontend id: `VOUCHERS.JOURNAL`
- Evidence: `accounting.constant.ts`
- Candidates: none

## `POST /payment`

- Frontend id: `VOUCHERS.PAYMENT`
- Evidence: `accounting.constant.ts · settings.integration.service.ts#SavePaymentKey`
- Candidates: none

## `GET /purchase`

- Frontend id: `VOUCHERS.PURCHASE`
- Evidence: `accounting.constant.ts`
- Candidates: none

## `GET /receipt`

- Frontend id: `VOUCHERS.RECEIPT`
- Evidence: `accounting.constant.ts`
- Candidates: none

## `GET /sales`

- Frontend id: `VOUCHERS.SALES`
- Evidence: `accounting.constant.ts`
- Candidates: none

## `POST /v2/company/:companyUniqueName/communication/email-template`

- Frontend id: `CUSTOM_EMAIL_TEMPLATE.CREATE_EMAIL_TEMPLATE`
- Evidence: `invoice.api.ts`
- Candidates: `PUT /v2/company/{companyUniqueName}/communication/email-template/{templateOf}` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/communication/email-template/{templateOf}` (giddh-api-v2), `PUT /v2/company/{companyUniqueName}/communication/email-template/{templateOf}/save-and-send` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/communication/email-template/{templateOf}/save-and-send` (giddh-api-v2), `GET /v2/company/{companyUniqueName}/communication/email-template/{templateOf}` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers`

- Frontend id: `ESTIMATES_API.base`
- Evidence: `proforma.api.ts · proforma.service.ts#get`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/download?fileType=:fileType`

- Frontend id: `ESTIMATES_API.download`
- Evidence: `proforma.api.ts · proforma.service.ts#download`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/generate`

- Frontend id: `ESTIMATES_API.generate`
- Evidence: `proforma.api.ts · proforma.service.ts#generate`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `GET /company/:companyUniqueName/vouchers/v3/:vouchers/all?`

- Frontend id: `ESTIMATES_API.getAll`
- Evidence: `proforma.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/project/{projectUniqueName}/entry/{entryUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}/merge` (giddh-api-v2)

## `POST /v2/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/versions/all?`

- Frontend id: `ESTIMATES_API.getVersions`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#getAllVersions; apps/web-giddh/src/app/services/voucher.service.ts#getVoucherVersions`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}/set-page-count` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}/get-page-count` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/report-comment` (giddh-api-v2), `DELETE /v2/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/report-comment` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/versions/all?`

- Frontend id: `ESTIMATES_API.getVersions`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#getAllVersions; apps/web-giddh/src/app/services/voucher.service.ts#getVoucherVersions`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}/set-page-count` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}/get-page-count` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/report-comment` (giddh-api-v2), `DELETE /v2/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/report-comment` (giddh-api-v2)

## `PUT /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/action`

- Frontend id: `ESTIMATES_API.updateAction`
- Evidence: `proforma.api.ts · proforma.service.ts#updateAction`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `GET /company/:companyUniqueName/:companyUniqueName/accounts/:accountUniqueName/vouchers/mail`

- Frontend id: `INVOICE_API_2.DOWNLOAD_INVOICE_V3`
- Evidence: `invoice.api.ts`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/accounts/:accountUniqueName/invoices/preview`

- Frontend id: `INVOICE_API_2.PREVIEW_INVOICE`
- Evidence: `invoice.api.ts`
- Candidates: `POST /v2/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/invoices/preview` (giddh-api-v2), `PUT /v2/company/{companyUniqueName}/communication/email-template/{templateOf}` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/communication/email-template/{templateOf}` (giddh-api-v2), `PUT /v2/company/{companyUniqueName}/communication/email-template/{templateOf}/save-and-send` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/communication/email-template/{templateOf}/save-and-send` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/settings/webhooks/:webhookUniquename`

- Frontend id: `INVOICE_API.DELETE_WEBHOOK`
- Evidence: `apps/web-giddh/src/app/services/invoice.service.ts#DeleteInvoiceWebhook`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `POST /company/:companyUniqueName/voucher/:voucherUniqueName/versions?page=:page&count=:count`

- Frontend id: `INVOICE_API.GET_ALL_VERSIONS`
- Evidence: `apps/web-giddh/src/app/services/invoice.service.ts#getVoucherVersions; apps/web-giddh/src/app/services/voucher.service.ts#getVoucherVersions`
- Candidates: `GET /company/{companyUniqueName}/voucher/{voucherUniqueName}/versions` (accounting-microservice), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `GET /company/:companyUniqueName/templates-v2/templateUniqueName`

- Frontend id: `INVOICE_API.GET_INVOICE_TEMPLATE`
- Evidence: `invoice.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/templates/all`

- Frontend id: `INVOICE_API.GET_INVOICE_TEMPLATES`
- Evidence: `invoice.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/settings/webhooks`

- Frontend id: `INVOICE_API.SAVE_INVOICE_WEBHOOK`
- Evidence: `apps/web-giddh/src/app/services/invoice.service.ts#SaveInvoiceWebhook`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/accounts/:accountUniqueName/invoices/mail`

- Frontend id: `INVOICE_API.SEND_INVOICE_ON_MAIL`
- Evidence: `invoice.api.ts`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2), `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/invoices/preview` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers`

- Frontend id: `PROFORMA_API.base`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#get; apps/web-giddh/src/app/services/proforma.service.ts#update; apps/web-giddh/src/app/services/voucher.service.ts#getEstimateProforma`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2)

## `PUT /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers`

- Frontend id: `PROFORMA_API.base`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#get; apps/web-giddh/src/app/services/proforma.service.ts#update; apps/web-giddh/src/app/services/voucher.service.ts#getEstimateProforma`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/download?fileType=:fileType`

- Frontend id: `PROFORMA_API.download`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#download`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/generate`

- Frontend id: `PROFORMA_API.generate`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#generate`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `POST /company/:companyUniqueName/vouchers/v3/:vouchers/all?`

- Frontend id: `PROFORMA_API.getAll`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#getAll; apps/web-giddh/src/app/services/voucher.service.ts#getAllProformaEstimate`
- Candidates: `PUT /company/{companyUniqueName}/project/{projectUniqueName}/entry/{entryUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}/merge` (giddh-api-v2)

## `POST /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/mail`

- Frontend id: `PROFORMA_API.mailProforma`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#sendEmail; apps/web-giddh/src/app/services/voucher.service.ts#sendProformaEstimateOnEmail`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `PUT /v3/company/:companyUniqueName/accounts/:accountUniqueName/:vouchers/action`

- Frontend id: `PROFORMA_API.updateAction`
- Evidence: `apps/web-giddh/src/app/services/proforma.service.ts#updateAction; apps/web-giddh/src/app/services/voucher.service.ts#updateAction`
- Candidates: `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/contacts` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/details` (giddh-api-v2), `DELETE /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/destroy-session` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/get-company-details` (giddh-api-v2)

## `DELETE /${COMMON_URL}recurring-vouchers/:recurringVoucherUniqueName?voucherVersion=2`

- Frontend id: `RECURRING_API.DELETE`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#delete`
- Candidates: none

## `GET /${COMMON_URL}recurring-vouchers/get-all-recurring-voucher?voucherType=:voucherType&page=:page&count=:count&q=:q&sort=:sort&sortBy=:sortBy&from=:from&to=:to&voucherVersion=2`

- Frontend id: `RECURRING_API.GET_ALL`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#getAll`
- Candidates: none

## `POST /${COMMON_URL}recurring-vouchers/preview?voucherVersion=2`

- Frontend id: `RECURRING_API.PREVIEW`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#preview`
- Candidates: none

## `GET /${COMMON_URL}recurring-vouchers/:recurringVoucherUniqueName?voucherVersion=2`

- Frontend id: `RECURRING_API.RULE_DETAILS`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#getRuleDetails`
- Candidates: none

## `PATCH /${COMMON_URL}recurring-vouchers/:recurringVoucherUniqueName?voucherVersion=2`

- Frontend id: `RECURRING_API.STATUS_UPDATE`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#updateStatus`
- Candidates: none

## `GET /${COMMON_URL}recurring-vouchers/:recurringVoucherUniqueName/details?voucherVersion=2`

- Frontend id: `RECURRING_API.VOUCHER_DETAILS`
- Evidence: `apps/web-giddh/src/app/services/aside-recurring-voucher.service.ts#getVoucherDetails`
- Candidates: none

## `POST /v4/company/:companyUniqueName/accounts/:accountUniqueName/invoices/generate-sales`

- Frontend id: `SALES_API_V4.GENERATE_SALES`
- Evidence: `sales.api.ts`
- Candidates: `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/project/{projectUniqueName}/entry/{entryUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/accounts/:accountUniqueName/purchase-order/versions/all?page=:page&count=:count`

- Frontend id: `PURCHASE_ORDER_API.GET_ALL_VERSIONS`
- Evidence: `apps/web-giddh/src/app/services/purchase-order.service.ts#getAllVersions; apps/web-giddh/src/app/services/voucher.service.ts#getVoucherVersions`
- Candidates: `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/purchase-order/versions/all` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/module/{module:.+}/ref/{refUniqueName:.+}` (giddh-api-v2), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName:.+}/vendor-contact/{vendorContactUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/accounts/:accountUniqueName/purchase-record/download-file`

- Frontend id: `PURCHASE_RECORD_API.DOWNLOAD_ATTACHMENT`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#downloadAttachedFile`
- Candidates: `GET /company/{companyUniqueName}/accounts/{accountUniqueName}/purchase-record/download-file` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2)

## `PATCH /company/:companyUniqueName/accounts/:accountUniqueName/purchase-record/generate`

- Frontend id: `PURCHASE_RECORD_API.GENERATE`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#generatePurchaseRecord`
- Candidates: `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/purchase-record/generate` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/accounts/:accountUniqueName/purchase-record/:uniqueName/download?fileType=base64`

- Frontend id: `PURCHASE_RECORD_API.GET_PDF`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#getPdf`
- Candidates: `GET /company/{companyUniqueName}/accounts/{accountUniqueName}/purchase-record/{uniqueName}/download` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/stock-aging-report/{stockUniqueName}/details` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/stock-aging-report/{stockUniqueName}/variants` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/platform/{platformUniqueName}/trigger/form` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/entity/{entity}/trigger/conditions` (giddh-api-v2)

## `POST /company/:companyUniqueName/accounts/:accountUniqueName/purchase-record`

- Frontend id: `PURCHASE_RECORD_API.UPDATE`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#generatePurchaseRecord`
- Candidates: `PATCH /company/{companyUniqueName}/accounts/{accountUniqueName}/purchase-record` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `GET /company/:companyUniqueName/accounts/:accountUniqueName/vouchers/download-file?fileType=base64`

- Frontend id: `PURCHASE_RECORD_API.V2.DOWNLOAD_ATTACHMENT`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#downloadAttachedFile`
- Candidates: `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/vouchers/download-file` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/accounts/:accountUniqueName/vouchers/download?fileType=base64`

- Frontend id: `PURCHASE_RECORD_API.V2.GET_PDF`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#getPdf`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2), `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/invoices/download` (giddh-api-v2)

## `GET /company/:companyUniqueName/accounts/:accountUniqueName/vouchers/download?fileType=base64`

- Frontend id: `PURCHASE_RECORD_API.V2.GET_PDF`
- Evidence: `apps/web-giddh/src/app/services/purchase-record.service.ts#getPdf`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2), `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/invoices/download` (giddh-api-v2)

## `POST /inventory-transfer/`

- Frontend id: `INVENTORY_API.BRANCH_TRANSFER.TRANSFER`
- Evidence: `inventory.api.ts · subscriptions.service.ts#transferSubscription`
- Candidates: none

## `POST /company/:companyUniqueName/stock-group/:stockGroupUniqueName/inventory-report-v2?from=:from&to=:to&count=:count&page=:page&sort=:sort&sortBy=:sortBy`

- Frontend id: `INVENTORY_API.GROUP_STOCK_REPORT_V2`
- Evidence: `inventory.api.ts`
- Candidates: `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `POST /company/:companyUniqueName/inventory/export-balance-report/group-wise?from=:from&to=:to&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_GROUP_WISE_EXPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getGroupWiseReportExport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/balance-report/group-wise?stockGroupUniqueName=:stockGroupUniqueName&from=:from&to=:to&count=:count&page=:page&sort=:sort&sortBy=:sortBy&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_GROUP_WISE_REPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getGroupWiseReport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/export-balance-report/item-wise?from=:from&to=:to&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_ITEM_WISE_EXPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getItemWiseReportExport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/balance-report/item-wise?from=:from&to=:to&count=:count&page=:page&sort=:sort&sortBy=:sortBy&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_ITEM_WISE_REPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getItemWiseReport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/export-balance-report/transaction-wise?from=:from&to=:to&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_TRANSACTION_EXPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getTransactionReportExport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/export-balance-report/variant-wise?from=:from&to=:to&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_VARIANT_WISE_EXPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getVariantWiseReportExport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /company/:companyUniqueName/inventory/balance-report/variant-wise?from=:from&to=:to&count=:count&page=:page&sort=:sort&sortBy=:sortBy&reportNature=:reportNature`

- Frontend id: `INVENTORY_API.INVENTORY_VARIANT_WISE_REPORT`
- Evidence: `apps/web-giddh/src/app/services/inventory.service.ts#getVariantWiseReport`
- Candidates: `POST /company/{companyUniqueName}/inventory/balance-report/{entity}` (giddh-api-v2), `POST /company/{companyUniqueName}/inventory/export-balance-report/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory/{stockGroupUniqueName}/masters` (search-api)

## `POST /inventory-transfer`

- Frontend id: `INVENTORY_API.TRANSFER_ENTRY.CREATE`
- Evidence: `inventory.api.ts`
- Candidates: none

## `PUT /company/:companyUniqueName/inventory-users/:inventoryUserUniqueName`

- Frontend id: `INVENTORY_API.USER.UPDATE`
- Evidence: `inventory.api.ts`
- Candidates: `PATCH /company/{companyUniqueName}/inventory-users/{inventoryUserUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/inventory-users/{inventoryUserUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/inventory-users/{inventoryUserUniqueName:.+}` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2)

## `GET /company/:companyUniqueName/:voucherType/:voucherUniqueName/event-resolutions`

- Frontend id: `INVENTORY_VOUCHER_API.EVENT_RESOLUTIONS`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#getInventoryEventResolutions`
- Candidates: `POST /company/{companyUniqueName}/communication/platform/verify` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/platform/{platformUniqueName}/trigger/form` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/entity/{entity}/trigger/conditions` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/campaign/list` (giddh-api-v2)

## `POST /company/:companyUniqueName/:voucherType/:voucherUniqueName/events`

- Frontend id: `INVENTORY_VOUCHER_API.EVENTS`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#executeInventoryDocumentEvent`
- Candidates: `POST /company/{companyUniqueName}/communication/platform/verify` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/platform/{platformUniqueName}/trigger/form` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/entity/{entity}/trigger/conditions` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/campaign/list` (giddh-api-v2)

## `POST /company/:companyUniqueName/:voucherType/generate`

- Frontend id: `INVENTORY_VOUCHER_API.GENERATE`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#generateInventoryVoucher`
- Candidates: `PATCH /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `DELETE /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2)

## `POST /company/:companyUniqueName/:voucherType/all`

- Frontend id: `INVENTORY_VOUCHER_API.GET_ALL`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#getAllInventoryVouchers`
- Candidates: `PATCH /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `DELETE /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2)

## `POST /company/:companyUniqueName/business-documents/:voucherUniqueName/versions`

- Frontend id: `INVENTORY_VOUCHER_API.HISTORY`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#getVoucherVersions`
- Candidates: `GET /company/{companyUniqueName}/business-documents/{uniqueName}/versions` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/:voucherType/:voucherUniqueName`

- Frontend id: `INVENTORY_VOUCHER_API.UPDATE`
- Evidence: `apps/web-giddh/src/app/services/voucher.service.ts#updateInventoryVoucher`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `POST /admin/auth/google/login` (giddh-api-v2), `PATCH /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `GET /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2), `DELETE /v3/admin/promo-code/{promoCodeUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstr-reconcile/auth?userName=:userName`

- Frontend id: `GST_RECONCILE_API.GENERATE_OTP`
- Evidence: `apps/web-giddh/src/app/services/gst-reconcile.service.ts#GstReconcileGenerateOtp`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/gstr-reconcile/verify-otp`

- Frontend id: `GST_RECONCILE_API.VERIFY_OTP`
- Evidence: `apps/web-giddh/src/app/services/gst-reconcile.service.ts#GstReconcileVerifyOtp`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/post-data-to-jiogst?from=:from&to=:to&gstin=:company_gstin`

- Frontend id: `GST_RETURN_API.FILE_JIO_GST_RETURN`
- Evidence: `apps/web-giddh/src/app/services/purchase-invoice.service.ts#FileGstReturn`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/taxpro/post-data-to-taxpro?gstin=:company_gstin&from=:from&to=:to`

- Frontend id: `GST_RETURN_API.FILE_TAX_PRO_RETURN`
- Evidence: `apps/web-giddh/src/app/services/purchase-invoice.service.ts#FileGstReturn`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2), `GET /company/{companyUniqueName}/ewb/taxpro/{ewbno}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/vayana/post-data-to-vayana?gstin=:company_gstin&from=:from&to=:to`

- Frontend id: `GST_RETURN_API.FILE_VAYANA_RETURN`
- Evidence: `apps/web-giddh/src/app/services/purchase-invoice.service.ts#FileGstReturn`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/:gstType-export-v2?gstin=:gstin&from=:from&to=:to&type=:sheetType`

- Frontend id: `GSTR_API.DOWNLOAD_SHEET`
- Evidence: `apps/web-giddh/src/app/services/gst-reconcile.service.ts#DownloadGSTRSheet`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/gstr1-transactions/documents-issued?gstin=:gstin&from=:from&to=:to`

- Frontend id: `GSTR_API.GET_DOCUMENT_ISSUED`
- Evidence: `gst-r.api.ts`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/:gstType-summary?gstin=:gstin&from=:from&to=:to`

- Frontend id: `GSTR_API.GET_OVERVIEW`
- Evidence: `apps/web-giddh/src/app/services/gst-reconcile.service.ts#GetGstrOverview; apps/web-giddh/src/app/services/gst-reconcile.service.ts#GetGstr3BOverview`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/:gstType-transactions/summary?page=:page&count=:count&gstin=:gstin&gstReturnType=:gstReturnType&from=:from&to=:to`

- Frontend id: `GSTR_API.GET_RETURN_SUMMARY`
- Evidence: `gst-r.api.ts`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/:gstType-transactions?gstin=:gstin&entityType=:entityType&type=:type&page=:page&count=:count&status=:status&from=:from&to=:to`

- Frontend id: `GSTR_API.GET_TRANSACTIONS`
- Evidence: `apps/web-giddh/src/app/services/gst-reconcile.service.ts#GetSummaryTransaction`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/gstr-transaction-count?gstin=:gstin&from=:from&to=:to`

- Frontend id: `GSTR_API.GET_TRANSACTIONS_COUNTS`
- Evidence: `gst-r.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/gstr2-error-export?monthYear=:month&gstin=:company_gstin`

- Frontend id: `PURCHASE_INVOICE_API.DOWNLOAD_GSTR2_ERROR_SHEET`
- Evidence: `purchase-invoice.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/gstr2-excel-export?monthYear=:month&gstin=:company_gstin`

- Frontend id: `PURCHASE_INVOICE_API.DOWNLOAD_GSTR2_EXCEL_SHEET`
- Evidence: `purchase-invoice.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/gstreturn/gstr2_data/file?monthYear=:month&gstin=:company_gstin`

- Frontend id: `PURCHASE_INVOICE_API.DOWNLOAD_GSTR2_SHEET`
- Evidence: `purchase-invoice.api.ts`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/vat-report-download-v2?from=:from&to=:to&taxNumber=:taxNumber&fileType=base64`

- Frontend id: `VAT_API.DOWNLOAD_REPORT`
- Evidence: `apps/web-giddh/src/app/services/vat.service.ts#downloadVatReport`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PATCH /company/:companyUniqueName/project?branchUniqueName=:branchUniqueName`

- Frontend id: `ACCOUNTING_API.CREATE_PROJECT`
- Evidence: `apps/web-giddh/src/app/project-wise-accounting/project-wise-accounting.service.ts#createNewProject`
- Candidates: `POST /company/{companyUniqueName}/project` (giddh-api-v2), `POST /company/{companyUniqueName}/project` (giddh-api-v2), `PATCH /company/{companyUniqueName}/project/{projectUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/project/all` (giddh-api-v2)

## `POST /company/:companyUniqueName/project/:projectUniqueName?branchUniqueName=:branchUniqueName`

- Frontend id: `ACCOUNTING_API.UPDATE_PROJECT`
- Evidence: `apps/web-giddh/src/app/project-wise-accounting/project-wise-accounting.service.ts#createNewProject; apps/web-giddh/src/app/project-wise-accounting/project-wise-accounting.service.ts#editProjectDetails`
- Candidates: `PATCH /company/{companyUniqueName}/project/{projectUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/project/{projectUniqueName}` (giddh-api-v2), `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `POST /company/{companyUniqueName}/communication/trigger` (giddh-api-v2)

## `GET /company/:companyUniqueName/exports?from=:from&to=:to&page=:page&count=:count`

- Frontend id: `DOWNLOADS_API.DOWNLOADS`
- Evidence: `apps/web-giddh/src/app/services/downloads.service.ts#getDownloads`
- Candidates: none

## `GET /v2/company/:companyUniqueName/trial-balance`

- Frontend id: `TB_PL_BS_API.GET_V2_TRIAL_BALANCE`
- Evidence: `apps/web-giddh/src/app/services/tl-pl.service.ts#GetV2TrailBalance`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/yodlee/ebanks/:itemAccountId`

- Frontend id: `EBANKS.ADD_GIDDH_ACCOUNT`
- Evidence: `settings.linked.accounts.api.ts`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/yodlee/yodlee-accounts?`

- Frontend id: `EBANKS.DELETE_BANK_ACCOUNT`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#DeleteBankAccount`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/yodlee/ebanks/:accountId`

- Frontend id: `EBANKS.LINK_ACCOUNT`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#LinkBankAccount`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `GET /company/:companyUniqueName/login/:loginId/token/reconnect`

- Frontend id: `EBANKS.RECONNECT_ACCOUNT`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#ReconnectAccount`
- Candidates: `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `POST /portal/company/{companyUniqueName}/accounts/{accountUniqueName}/{voucherUniqueName}/add-comment` (accounting-microservice), `GET /portal/company/{companyUniqueName}/accounts/{accountUniqueName}/{voucherUniqueName}/comments` (accounting-microservice)

## `GET /company/:companyUniqueName/ebanks/refresh`

- Frontend id: `EBANKS.REFRESH_ACCOUNTS`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#RefreshAllEbankAccounts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/yodlee/refresh/:ebankItemId`

- Frontend id: `EBANKS.REFREST_ACCOUNT`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#RefreshBankAccount`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/yodlee/ebanks/:ItemAccountId/unlink`

- Frontend id: `EBANKS.REMOVE_GIDDH_ACCOUNT`
- Evidence: `settings.linked.accounts.api.ts`
- Candidates: `PUT /company/{companyUniqueName}/project/{projectUniqueName}/entry/{entryUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/groups/{groupUniqueName}/accounts/{accountUniqueName:.+}/merge` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/yodlee/ebanks/:accountId?accountUniqueName=:accountUniqueName`

- Frontend id: `EBANKS.UNLINK_ACCOUNT`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#UnlinkBankAccount`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `PUT /company/:companyUniqueName/yodlee/:accountId/eledgers?from=:date`

- Frontend id: `EBANKS.UPDATE_DATE`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#UpdateDate`
- Candidates: `DELETE /company/{companyUniqueName}/communication/platform/{uniqueName}` (giddh-api-v2), `PUT /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/communication/trigger/{triggerUniqueName}` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/discount`

- Frontend id: `SETTINGS_DISCOUNT_API.COMMON`
- Evidence: `apps/web-giddh/src/app/services/settings.discount.service.ts#GetDiscounts; apps/web-giddh/src/app/services/settings.discount.service.ts#CreateDiscount; apps/web-giddh/src/app/services/settings.discount.service.ts#DeleteDiscount`
- Candidates: `POST /company/{companyUniqueName}/discount` (giddh-api-v2), `GET /company/{companyUniqueName}/discount` (giddh-api-v2), `POST /company/{companyUniqueName}/discount` (giddh-api-v2), `PUT /company/{companyUniqueName}/discount/{discountUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/discount` (giddh-api-v2)

## `GET /company/:companyUniqueName/amazon/seller`

- Frontend id: `SETTINGS_INTEGRATION_API.AMAZON_SELLER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAmazonSeller; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAmazonSeller`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/amazon/seller`

- Frontend id: `SETTINGS_INTEGRATION_API.AMAZON_SELLER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAmazonSeller; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAmazonSeller`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/amazon/seller/:sellerId`

- Frontend id: `SETTINGS_INTEGRATION_API.AMAZON_SELLER_OPERATION`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAmazonSeller; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAmazonSeller`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/amazon/seller/:sellerId`

- Frontend id: `SETTINGS_INTEGRATION_API.AMAZON_SELLER_OPERATION`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAmazonSeller; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAmazonSeller`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `GET /company/:companyUniqueName/cashfree/autocollect/users`

- Frontend id: `SETTINGS_INTEGRATION_API.AUTOCOLLECT_USER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAutoCollectUser`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `POST /company/:companyUniqueName/cashfree/autocollect/users`

- Frontend id: `SETTINGS_INTEGRATION_API.AUTOCOLLECT_USER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAutoCollectUser`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/cashfree/autocollect/users`

- Frontend id: `SETTINGS_INTEGRATION_API.AUTOCOLLECT_USER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAutoCollectUser`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/cashfree/autocollect/users`

- Frontend id: `SETTINGS_INTEGRATION_API.AUTOCOLLECT_USER`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#AddAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateAutoCollectUser; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteAutoCollectUser`
- Candidates: `GET /company/{companyUniqueName}/currency-converter/{baseCurrency}/{toCurrency}` (giddh-api-v2)

## `POST /company/:companyUniqueName/cashfree`

- Frontend id: `SETTINGS_INTEGRATION_API.CASHFREE`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#SaveCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#GetCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteCashFreeDetail`
- Candidates: none

## `GET /company/:companyUniqueName/cashfree`

- Frontend id: `SETTINGS_INTEGRATION_API.CASHFREE`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#SaveCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#GetCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteCashFreeDetail`
- Candidates: none

## `PUT /company/:companyUniqueName/cashfree`

- Frontend id: `SETTINGS_INTEGRATION_API.CASHFREE`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#SaveCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#GetCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteCashFreeDetail`
- Candidates: none

## `DELETE /company/:companyUniqueName/cashfree`

- Frontend id: `SETTINGS_INTEGRATION_API.CASHFREE`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#SaveCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#GetCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdateCashFreeDetail; apps/web-giddh/src/app/services/settings.integration.service.ts#DeleteCashFreeDetail`
- Candidates: none

## `GET /company/:companyUniqueName/cashfree/payment-gateway`

- Frontend id: `SETTINGS_INTEGRATION_API.PAYMENT_GATEWAY`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#AddPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdatePaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#DeletePaymentGateway`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/cashfree/payment-gateway`

- Frontend id: `SETTINGS_INTEGRATION_API.PAYMENT_GATEWAY`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#AddPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdatePaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#DeletePaymentGateway`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/cashfree/payment-gateway`

- Frontend id: `SETTINGS_INTEGRATION_API.PAYMENT_GATEWAY`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#AddPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdatePaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#DeletePaymentGateway`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `DELETE /company/:companyUniqueName/cashfree/payment-gateway`

- Frontend id: `SETTINGS_INTEGRATION_API.PAYMENT_GATEWAY`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#GetPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#AddPaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#UpdatePaymentGateway; apps/web-giddh/src/app/services/settings.integration.service.ts#DeletePaymentGateway`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `PUT /company/:companyUniqueName/payu`

- Frontend id: `SETTINGS_INTEGRATION_API.PAYU_CRUD`
- Evidence: `apps/web-giddh/src/app/services/settings.integration.service.ts#payuCrudOperation`
- Candidates: `POST /company/{companyUniqueName}/payu` (giddh-api-v2), `GET /company/{companyUniqueName}/payu` (giddh-api-v2), `DELETE /company/{companyUniqueName}/payu` (giddh-api-v2), `POST /company/{companyUniqueName}/payu` (giddh-api-v2), `GET /company/{companyUniqueName}/payu` (giddh-api-v2)

## `GET /company/:companyUniqueName/yodlee/access-token`

- Frontend id: `YODLEE_FASTLINK.ACCESS_TOKEN`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#GetYodleeToken`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/yodlee/add-provider-account?providerId=:providerId`

- Frontend id: `YODLEE_FASTLINK.ADD_PROVIDER`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#AddProvider`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/yodlee/yodlee-accounts`

- Frontend id: `YODLEE_FASTLINK.GET_ACCOUNTS`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#GetYodleeAccounts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/yodlee/status/:providerId`

- Frontend id: `YODLEE_FASTLINK.GET_BANK_SYNC_STATUS`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#GetBankSyncStatus`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `GET /company/:companyUniqueName/yodlee/login-form/:providerId`

- Frontend id: `YODLEE_FASTLINK.GET_LOGIN_FORM`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#GetLoginForm`
- Candidates: `POST /company/{companyUniqueName}/sync-data/{ecommerceUniqueName}/stocks` (giddh-api-v2), `POST /company/{companyUniqueName}/domain/{domainUniqueName}/share` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/entries` (giddh-api-v2), `GET /company/{companyUniqueName}/project/{projectUniqueName}/category-total` (giddh-api-v2), `POST /company/{companyUniqueName}/project/{projectUniqueName}/entry` (giddh-api-v2)

## `GET /company/:companyUniqueName/yodlee/search?name=:queryString`

- Frontend id: `YODLEE_FASTLINK.SEARCH_BANKS`
- Evidence: `apps/web-giddh/src/app/services/settings.linked.accounts.service.ts#SearchBank`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /subscriptions/:subscriptionId/companies`

- Frontend id: `SUBSCRIPTIONS_API.SUBSCRIBED_COMPANIES_LIST`
- Evidence: `apps/web-giddh/src/app/services/subscriptions.service.ts#GetSubscribedCompaniesList`
- Candidates: `POST /subscriptions/{subscriptionId}/companies` (giddh-api-v2), `POST /subscriptions/{subscriptionId}/companies` (giddh-api-v2)

## `GET /subscriptions/company/:company/transactions?from=:from&to=:to&interval=:interval`

- Frontend id: `SUBSCRIPTIONS_API.SUBSCRIBED_COMPANY_TRANSACTIONS`
- Evidence: `apps/web-giddh/src/app/services/subscriptions.service.ts#GetSubScribedCompanyTransaction`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /subscriptions/:subscriptionId/all-transactions?from=:from&to=:to&interval=:interval`

- Frontend id: `SUBSCRIPTIONS_API.SUBSCRIBED_USER_TRANSACTIONS`
- Evidence: `apps/web-giddh/src/app/services/subscriptions.service.ts#GetSubScribedUserTransaction`
- Candidates: none

## `GET /company/:companyUniqueName/imports/all-document?branchUniqueName=:branchUniqueName&page=:page&count=:count&from=:from&to=:to&sort=:sort&sortBy=:sortBy&ocrType=:ocrType`

- Frontend id: `AI_OCR_API.GET_ALL_DOCUMENTS`
- Evidence: `ai-ocr.api.ts`
- Candidates: `POST /company/{companyUniqueName}/imports/all-document` (import-microservice), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `POST /company/:companyUniqueName/imports/signed-url?fileName=:fileName&branchUniqueName=:branchUniqueName`

- Frontend id: `AI_OCR_API.UPLOAD_DOCUMENTS`
- Evidence: `ai-ocr.api.ts`
- Candidates: `GET /company/{companyUniqueName}/imports/signed-url` (import-microservice), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/imports/status?page=:page&count=:count`

- Frontend id: `IMPORT_EXCEL_API.IMPORT_STATUS`
- Evidence: `apps/web-giddh/src/app/services/import-excel.service.ts#importStatus`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/tally_logs/completed`

- Frontend id: `TALLY_SYNC_API.COMPLETED`
- Evidence: `tally-sync.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/tally_logs/error_report`

- Frontend id: `TALLY_SYNC_API.ERROR_LOG`
- Evidence: `tally-sync.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/tally_logs/current_day`

- Frontend id: `TALLY_SYNC_API.INPROGRESS`
- Evidence: `tally-sync.ts`
- Candidates: `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2), `GET /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

## `GET /company/:companyUniqueName/accounts/:accountUniqueName/vouchers/download-file?fileType=:fileType`

- Frontend id: `COMMON_API.DOWNLOAD_FILE_V1`
- Evidence: `common.api.ts`
- Candidates: `POST /company/{companyUniqueName}/accounts/{accountUniqueName}/vouchers/download-file` (giddh-api-v2), `GET /company/{companyUniqueName}/communication/suggestions/{platformUniqueName}/{entity}` (giddh-api-v2), `GET /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `PUT /company/{companyUniqueName}/accounts/v2/{accountUniqueName:.+}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/accounts/{accountUniqueName:.+}/entries/{entryUniqueName:.+}` (giddh-api-v2)

## `GET /v2/subscription/paypal-subscription-callback`

- Frontend id: `COMMON_API.SUBSCRIPTION_PAYPAL_CALL_BACK`
- Evidence: `common.api.ts`
- Candidates: `GET /v2/subscription/{subscriptionId}/cancel` (giddh-api-v2), `GET /v2/subscription/{subscriptionId}/with-payment-info` (giddh-api-v2), `GET /v2/subscription/{subscriptionId}/payment-methods` (giddh-api-v2), `GET /v2/subscription/{subscriptionId}` (giddh-api-v2), `GET /v2/subscription/{subscriptionId}/activate` (giddh-api-v2)

## `POST /${COMPANY_BASE_URL}/email-forwarding`

- Frontend id: `EMAIL_FORWARDING_API.CREATE_EMAIL_FORWARDING`
- Evidence: `apps/web-giddh/src/app/email-forwarding/services/email-forwarding.service.ts#createEmailForwarding`
- Candidates: none

## `DELETE /${COMPANY_BASE_URL}/email-forwarding/:uniqueName`

- Frontend id: `EMAIL_FORWARDING_API.DELETE_EMAIL_FORWARDING`
- Evidence: `apps/web-giddh/src/app/email-forwarding/services/email-forwarding.service.ts#deleteEmailForwarding`
- Candidates: none

## `GET /${COMPANY_BASE_URL}/email-forwarding/get-all`

- Frontend id: `EMAIL_FORWARDING_API.GET_ALL_EMAIL_FORWARDING`
- Evidence: `apps/web-giddh/src/app/email-forwarding/services/email-forwarding.service.ts#getAllEmailForwarding`
- Candidates: none

## `GET /${COMPANY_BASE_URL}/email-forwarding/:uniqueName`

- Frontend id: `EMAIL_FORWARDING_API.GET_EMAIL_FORWARDING`
- Evidence: `apps/web-giddh/src/app/email-forwarding/services/email-forwarding.service.ts#getEmailForwarding`
- Candidates: none

## `PUT /${COMPANY_BASE_URL}/email-forwarding/:uniqueName`

- Frontend id: `EMAIL_FORWARDING_API.UPDATE_EMAIL_FORWARDING`
- Evidence: `apps/web-giddh/src/app/email-forwarding/services/email-forwarding.service.ts#updateEmailForwarding`
- Candidates: none

## `GET /ui/error-recorder`

- Frontend id: `ERROR_LOG_API`
- Evidence: `exception-log.api.ts`
- Candidates: `POST /ui/error-recorder` (giddh-api-v2), `POST /ui/error-recorder` (giddh-api-v2)

## `GET /ui/exception`

- Frontend id: `EXCEPTION_API`
- Evidence: `exception-log.api.ts`
- Candidates: `POST /ui/exception` (giddh-api-v2), `POST /ui/exception` (giddh-api-v2)

## `GET /v2/company/:companyUniqueName/account-balances`

- Frontend id: `INLINE.contact.accountBalances`
- Evidence: `contact.service.ts · contact.service.ts`
- Candidates: `POST /v2/company/{companyUniqueName}/stock-aging-report` (giddh-api-v2), `PUT /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `GET /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `DELETE /company/{companyUniqueName}/gst-setting/{uniqueName}` (giddh-api-v2), `PATCH /company/{companyUniqueName}/customfield/{customFieldUniqueName:.+}` (giddh-api-v2)

